This is the SysML model for VeTeSS UC3 (e-shift), used to evaluate the Topcased VeTeSS plugin

Instructions for opening the model:
1.	If Topcased is not already installed, download Topcased 5.3.0 and install it by
    unzipping its archive.
2.	Start Topcased by running its executable file
3.	Install the VeTeSS Topcased Verification plugin by the update site.
	3.1 Select the Help � Install New Software menu item. 
	3.2 In the Available Software window that appears, type http://typhoon5.polito.it/vetess/update-site and then click on the Add button. 
	3.3 You will see a � Verification� category with the VeTeSS_TopcasedPluginFeature. Select the most recent version and then click on Finish.
4.	Unzip the archive where you have found this readme file into a folder in your local disk and then import the project into your workspace as follows:
	4.1	select the File � Import � Existing Projects into Workspace menu item. Then click the Next button.
	4.2	In the form that appears, enter the location where you have unzipped the archive. Select the project that appears, then select the �copy projects into workspace� option box and click Finish. 
	4.3	The project will appear in the Project Explorer in the left hand side of the work area.
5.	Open the project as follows:
	5.1	Select the project in the Project Explorer and right click on it
	5.2	In the contextual menu, select Open Project.
	5.3	Select the crf_eshift.sysmldi file inside the Models folder and double click on it
6.	Navigate to the various diagrams included in the model by using the Outline view.
    Inside package �concept� it is possible to find all the main diagrams (the system architecture diagrams and the requirements diagrams).

Important note: in order to be able to use the plugin verification and test generation functions,
it is necessary to first install the plugin dependencies (PAT and CADP/TGV) as explained in the
project deliverables.